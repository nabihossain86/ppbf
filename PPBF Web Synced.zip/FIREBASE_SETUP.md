# Turning on live sync for Total Assets (10 minutes, free tier)

Without this step the dashboard works, but records/documents stay on the device that added them
(the status pill says "This device only"). Steps:

1. console.firebase.google.com -> use your existing PPBF project (or create one).
2. Build -> Realtime Database -> Create database. Copy its URL (https://xxxx-default-rtdb....firebasedatabase.app).
3. Build -> Authentication -> Sign-in method -> enable Email/Password.
   Users tab -> Add user: email `admin@ppbf.org`, a strong password (this is the "cloud save password").
   Settings -> User actions -> UNTICK "Enable create (sign-up)" so nobody else can create accounts.
4. Realtime Database -> Rules -> paste the contents of `database.rules.json` -> Publish.
   Only the signed-in admin@ppbf.org can write. Everyone can read (same as the rest of the site).
   To make everything private, change the three `".read": true` to `"auth != null"` (viewers must then sign in).
5. Project settings -> General -> Web API key. In BOTH html files find `const SYNC={url:'',apiKey:''` and fill:
   `url:'https://xxxx-default-rtdb....firebasedatabase.app'`, `apiKey:'AIza...'`.
6. Open the site, switch to Edit, upload something. The pill turns green: "Live · synced on all devices".

Notes
- Files are stored in the Realtime Database (max 6 MB each; photos are auto-compressed). Free tier = 1 GB total.
- Upload queue is kept on the device: if offline, changes show "pending" and upload when back online.
- Export Backup / Reset in the Admin panel do not include Total Assets records or documents.
